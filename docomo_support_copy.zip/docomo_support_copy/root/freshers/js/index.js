$(function () {

	//メニューurl取得
	var navArray = [];
	$('.navListPc li').each(function () {
		var navUrl = $(this).find('a').attr('href');
		navArray.push(navUrl);
	});
	//メニューにcurrentクラス付与
	$.each(navArray, function (i) {
		if (document.URL.match(navArray[i])) {
			$('.navListPc li').eq(i).find('a').addClass('current');
		}
	})

	//SPメニューON/OFF
	var navBtn = $('#navBtn');
	var navItem = $('#nav');
	navBtn.on('click', function () {
		if ($(this).hasClass('active')) {
			$(this).removeClass('active');
			navItem.removeClass('active');
			$('body').removeClass('fixed');
		} else {
			$(this).addClass('active');
			navItem.addClass('active');
			$('body').addClass('fixed');
		}
	});

	//スムーススクロール
	$('a[href^="#"]').on('click', function () {
		var speed = 400;
		var href = $(this).attr('href');
		var target = $(href == '#' || href == '' ? 'html' : href);
		var position = target.offset().top;
		$('body,html').animate({
			scrollTop: position
		}, speed, 'swing');
		return false;
	});

	//アコーディオン
	$('.accBlock').each(function(){
		var acc = $(this);
		var openH = acc.find('.accBody').height();
		acc.addClass('close');
		var closeH = acc.find('.accBody').height();
		acc.find('.accTxt').text('続きを読む');
		acc.find('.accTrigger').on('click', function(){
			var parent = $(this).closest('.accBlock');
			if(parent.hasClass('close')){
				parent.find('.accBody').animate({height: openH}, 300);
				parent.removeClass('close');
				parent.find('.accTxt').text('閉じる');
			}else{
				parent.find('.accBody').animate({height: closeH}, 300);
				parent.addClass('close');
				parent.find('.accTxt').text('続きを読む');
			}
		});
	});

});

//前のページへ
function prev() {
	history.back();
}
