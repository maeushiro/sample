$(function () {
	//スムーススクロール
	$('a[href^="#"]').on('click', function () {
		var speed = 400;
		var href = $(this).attr('href');
		var target = $(href == '#' || href == '' ? 'html' : href);
		var position = target.offset().top;
		$('body,html').animate({
			scrollTop: position
		}, speed, 'swing');
		return false;
	});

	//画面下追従
	$('.footer').css('padding-bottom', '70px');
	var trgr = $('#fixedBtmTrgr');
			trgrH = trgr.height(),
			trgrTop = trgr.offset().top,
			trgrPos = trgrH + trgrTop,
			fItem = $('#fixedBtmItem');
	$(window).on('scroll', function () {
		var top = window.pageYOffset;

		function bottom(n) {
			fItem.css('bottom', n);
		}
		top > trgrPos ? bottom('0') : bottom('-100%');
	});

	//アコーディオン
	$('.accBody01, .accBody02, .accBody03').css('display', 'none'); //閉
	function accFnc(wrap, trigger, body) {
		wrap.each(function () {
			$(this).find(trigger).on('click', function () {
				var item = $(this).closest(wrap).find(body);
				if (body.hasClass('accBody01') === true) {
					body.not(item).slideUp().removeClass('open');
					$('.accBody02').slideUp().removeClass('open');
					trigger.not($(this)).removeClass('icoClose');
					$('.accTrigger02').removeClass('icoClose');
				};
				if (item.hasClass('open')) {
					item.removeClass('open').slideUp();
					item.closest(wrap).find(trigger).removeClass('icoClose');
				} else {
					item.addClass('open').slideDown();
					item.closest(wrap).find(trigger).addClass('icoClose');
				}
			});
		});
	};
	var w01 = $('.accWrap01'), t01 = $('.accTrigger01'), b01 = $('.accBody01');
	var w02 = $('.accWrap02'), t02 = $('.accTrigger02'), b02 = $('.accBody02');
	var w03 = $('.accWrap03'), t03 = $('.accTrigger03'), b03 = $('.accBody03');
	accFnc(w01, t01, b01);
	accFnc(w02, t02, b02);
	accFnc(w03, t03, b03);
});